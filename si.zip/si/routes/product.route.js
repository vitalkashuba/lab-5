const express = require("express");
const router = express.Router();
const { getClips, getClip, createClip, updateClip, deleteClip } = require('../controllers/product.controler.js');

router.get('/', getClips);
router.get("/:id", getClip);
router.post("/", createClip);
router.put("/:id", updateClip);
router.delete("/:id", deleteClip);

module.exports = router;

