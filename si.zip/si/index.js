const express = require("express");
const mongoose = require("mongoose");
const Product = require("./models/product.model.js");
const app = express();
const productRoute = require("./routes/product.route.js"); 

const cors = require('cors');
app.use(cors());
// middleware
app.use(express.json());
//app.use(express.urlencoded({ extended: false }));
app.use("/api/clips", productRoute);
// routes
app.use("/api/products", productRoute);

app.get("/", (req, res) => {
  res.send("Hello from Node API Server Updated");
});

// Підключення до бази даних
mongoose
  .connect(
    "mongodb+srv://vitalijsubak:shubak2006@backend.mfgpe.mongodb.net/?retryWrites=true&w=majority&appName=backend"
  )
  .then(() => {
    console.log("Connected to database!");
    app.listen(3100, () => {
      console.log("Server is running on port 3100");
    });
  })
  .catch((error) => {
    console.log("Connection failed: ", error);
  });
