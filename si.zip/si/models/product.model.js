const mongoose = require("mongoose");

const ClipSchema = mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Будь ласка, введіть назву кліпу"],
    },
    url: {
      type: String,
      required: [true, "Будь ласка, введіть URL кліпу"],
    },
    description: {
      type: String,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

const Clip = mongoose.model("Clip", ClipSchema);

module.exports = Clip;
