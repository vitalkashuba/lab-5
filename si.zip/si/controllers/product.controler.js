const Clip = require("../models/product.model"); // Імпортуємо модель кліпа

const getClips = async (req, res) => {
  try {
    const clips = await Clip.find({});
    res.status(200).json(clips);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getClip = async (req, res) => {
  try {
    const { id } = req.params;
    const clip = await Clip.findById(id);
    if (!clip) {
      return res.status(404).json({ message: "Кліп не знайдено" });
    }
    res.status(200).json(clip);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const createClip = async (req, res) => {
  try {
    const clip = await Clip.create(req.body);
    res.status(201).json(clip);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const updateClip = async (req, res) => {
  try {
    const {id} = req.params;
    const clip = await Clip.findByIdAndUpdate(id, req.body, { new: true });
    if (!clip) {
      return res.status(404).json({ message: "Кліп не знайдено" });
    }
    res.status(200).json(clip);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const deleteClip = async (req, res) => {
  try {
    const {id} = req.params;
    const clip = await Clip.findByIdAndDelete(id);
    if (!clip) {
      return res.status(404).json({ message: "Кліп не знайдено" });
    }
    res.status(200).json({ message: "Кліп успішно видалено" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getClips,
  getClip,
  createClip,
  updateClip,
  deleteClip,
};
