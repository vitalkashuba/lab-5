document.addEventListener('DOMContentLoaded', function () {
    const updateForm = document.getElementById('update-form');

    const form = document.getElementById('product-form');
    const productList = document.getElementById('product-list');

    // Функція для отримання продуктів
    async function fetchProducts() {
        const response = await fetch('http://localhost:3100/api/products');
        const products = await response.json();
        productList.innerHTML = '';
        products.forEach(product => {
            const li = document.createElement('li');
            li.innerHTML = `
                <strong>${product.title}</strong>
                <p>Силка: ${product.url}</p>
                <p>Опис ${product.description} </p>
                <button class="delete-btn" data-id="${product._id}">Видалити</button>
                <button class="update-btn" data-id="${product._id}">Редагувати</button>
            `;
            productList.appendChild(li);
        });
        const updateButtons = document.querySelectorAll('.update-btn');
        updateButtons.forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                fetchProduct(productId);
            });
        });
        // Додаємо подію для кнопок видалення після завантаження продуктів
        const deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                deleteProduct(productId);
            });
        });
    }

    // Функція для додавання продукту
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const name = document.getElementById('title').value;
        const url = document.getElementById('url').value;
        const description = document.getElementById('description').value;

        const response = await fetch('http://localhost:3100/api/products', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title: name, url: url, description: description })
        });

        if (response.ok) {
            fetchProducts();
            form.reset();
        } else {
            console.error('Error adding product:', response.statusText);
        }
    });

    // Функція для видалення продукту за id
    async function deleteProduct(productId) {
        const response = await fetch(`http://localhost:3100/api/products/${productId}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            fetchProducts();
        } else {
            console.error('Error deleting product:', response.statusText);
        }
    }
    let currentProductId = null; // Зберігаємо ідентифікатор для редагування

// Функція для отримання даних продукту
async function fetchProducts() {
    const response = await fetch('http://localhost:3100/api/products');
    const products = await response.json();
    productList.innerHTML = '';
    products.forEach(product => {
        const li = document.createElement('li');
        li.innerHTML = `
            <strong>${product.title}</strong>
            <p>Силка: ${product.url}</p>
            <p>Опис: ${product.description}</p>
            <button class="delete-btn" data-id="${product._id}">Видалити</button>
            <button class="update-btn" data-id="${product._id}">Редагувати</button>
        `;
        productList.appendChild(li);
    });
    
    // Додаємо події для кнопок
    document.querySelectorAll('.update-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.getAttribute('data-id');
            fetchProduct(productId);
        });
    });

    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.getAttribute('data-id');
            deleteProduct(productId);
        });
    });
};
async function editProduct(productId) {
    try {
        const response = await fetch(`http://localhost:3100/api/products/${productId}`);
        
        if (!response.ok) {
            throw new Error('Failed to fetch product for editing');
        }

        const product = await response.json();

        // Заповнюємо поля форми редагування даними про продукт
        document.getElementById('update-title').value = product.title;
        document.getElementById('update-url').value = product.url;
        document.getElementById('update-description').value = product.description;

        // Зберігаємо ідентифікатор для подальшого редагування
        currentProductId = productId;

        // Показуємо форму редагування
        document.getElementById('update-form-container').style.display = 'block';

    } catch (error) {
        console.error('Error fetching product for edit:', error);
    }
}

// Обробник події для кнопки "Редагувати"
document.getElementById('product-list').addEventListener('click', function (event) {
    if (event.target.classList.contains('update-btn')) {
        const productId = event.target.getAttribute('data-id');
        editProduct(productId);
    }
});

    // Функція для оновлення продукту
    
    updateForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // Зупиняємо стандартну поведінку форми

        // Отримуємо значення з полів форми
        const title = document.getElementById('update-title').value;
        const url = document.getElementById('update-url').value;
        const description = document.getElementById('update-description').value;

        try {
            const response = await fetch(`http://localhost:3100/api/products/${currentProductId}`, {
                method: 'PUT', // Використовуємо метод PUT для оновлення
                headers: {
                    'Content-Type': 'application/json' // Вказуємо тип вмісту
                },
                body: JSON.stringify({ title, url, description }) // Відправляємо нові дані
            });

            if (response.ok) {
                await fetchProducts(); // Оновлюємо список продуктів
                updateForm.style.display = 'none'; // Ховаємо форму редагування
                updateForm.reset(); // Скидаємо форму
            } else {
                console.error('Error updating product:', response.statusText);
            }
        } catch (error) {
            console.error('Network error while updating product:', error); // Логування мережевих помилок
        }
    });

    // Обробник події для кнопки "Скасувати"
    document.getElementById('cancel-update').addEventListener('click', () => {
        updateForm.style.display = 'none'; // Сховати форму редагування
        updateForm.reset(); // Скинути форму, якщо потрібно
    });



    // Завантажуємо продукти при старті
    fetchProducts();
    console.log('DOM повністю завантажений');
});

    